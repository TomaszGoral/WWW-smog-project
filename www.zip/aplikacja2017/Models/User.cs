﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace aplikacja2017.Models
{
    public class User
    {
        public string user { get; set; }
        public string password { get; set; }
    }
}